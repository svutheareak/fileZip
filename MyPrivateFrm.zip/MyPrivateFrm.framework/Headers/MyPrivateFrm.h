//
//  MyPrivateFrm.h
//  MyPrivateFrm
//
//  Created by Sam Vutheareak on 27/9/23.
//

#import <Foundation/Foundation.h>

//! Project version number for MyPrivateFrm.
FOUNDATION_EXPORT double MyPrivateFrmVersionNumber;

//! Project version string for MyPrivateFrm.
FOUNDATION_EXPORT const unsigned char MyPrivateFrmVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyPrivateFrm/PublicHeader.h>


